public class Deposit {
    public final double amount;
    public Deposit(double amount){
        this.amount = amount;
    }
}
