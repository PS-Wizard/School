/**
 * 
 */
/**
 * 
 */
module TextBasedAdventure {
}