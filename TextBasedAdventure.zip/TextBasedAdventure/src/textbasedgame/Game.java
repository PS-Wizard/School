import java.util.Random;
import java.util.Scanner;

public class Game {
    static int health = 100;
    static int energy = 100;
    static int probabilitySuccessTuna = 1; 
    static String name;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Random random = new Random();

        System.out.println("Welcome, adventurer type shit: ");
        System.out.print("Enter your meow meow name: ");
        name = in.nextLine(); // Get the player's name

        System.out.println("\nYou are " + name + ", the sneakiest cat in the city.");
        System.out.println("Legend has it that the Dog Mafia guards the Golden Tuna. Will you steal it?"); // Lore Determined by GPT
        home(in, random); // Go to the home screen

        in.close(); // Close the scanner
    }

    /* 
     * This is the home function where the player can choose their next move. 
     * They can spy, visit the Cat Council, take a nap, or attempt the heist.
     */
    public static void home(Scanner in, Random random) {
        if (energy <= 0 || health <= 0) {
            System.out.println("\nYou collapse... Maybe being a rogue cat isn’t easy after all.");
            return; // End the game if health or energy is 0
        }

        System.out.println("\nBack at your alley hideout, you plot your next move...");
        System.out.println("1. Spy on the Dog Mafia");
        System.out.println("2. Visit the Cat Council");
        System.out.println("3. Take a nap");
        System.out.println("4. Attempt to steal the Golden Tuna");
        System.out.print("Choose: ");

        String choice = in.nextLine(); // Get player’s choice

        // Handle different choices
        switch (choice) {
            case "1" -> spyOnDogs(in, random); // If the player chooses to spy on dogs
            case "2" -> visitCatCouncil(in, random); // If they choose to visit the council
            case "3" -> takeNap(); // If they choose to nap
            case "4" -> stealGoldenTuna(in, random); // If they want to steal the Tuna
            default -> {
                System.out.println("\nInvalid choice, try again!"); // If they pick an invalid option
                home(in, random); // Go back to home screen
            }
        }
    }

    /* 
     * This is the function for spying on the Dog Mafia. 
     * The player might get useful information or hurt in the process.
     */
    public static void spyOnDogs(Scanner in, Random random) {
        System.out.println("\nYou sneak into the Dog Mafia’s territory...");
        int outcome = random.nextInt(3); // Randomly determine the outcome

        // Random outcomes based on spying
        if (outcome == 0) {
            System.out.println("You overhear their secret plan! (+10% success chance for heist, -5 energy)");
            probabilitySuccessTuna += 10; // Increase success chance for heist
            energy -= 5;
        } else if (outcome == 1) {
            System.out.println("A guard dog spots you! (-20 health)");
            health -= 20; // Lose health if spotted
        } else {
            System.out.println("You find a shortcut to their hideout! (shortcut saved wasting energy, +5% success chance)");
            probabilitySuccessTuna += 5; // Increase success chance a little
        }
        home(in, random); // Return to the home screen
    }

    /* 
     * The function where the player gets advice or rewards from the Cat Council.
     * It either boosts health or success chance.
     */
    public static void visitCatCouncil(Scanner in, Random random) {
        System.out.println("\nThe wise old cats listen to your plan...");
        int outcome = random.nextInt(2); 

        if (outcome == 0) {
            System.out.println("They grant you a magic collar! (+30 health)");
            health += 30; // Magic collar increases health
        } else {
            System.out.println("They grant you advice! (+5 success chance)");
            probabilitySuccessTuna += 10; // Advice boosts success chance
        }
        home(in, random); // Return to the home screen
    }

    /* 
     * This function lets the player take a nap and restores energy.
     * They might also have dreams that affect success chance.
     */
    public static void takeNap() {
        System.out.println("\nYou find a cozy sunbeam and curl up for a nap...");

        Random random = new Random();
        int dream = random.nextInt(3); // Random dream outcome

        // Different outcomes based on the dream
        if (dream == 0) {
            System.out.println("You dream of chasing an endless army of red laser dots. So close, yet so far... (+20 energy)");
            energy += 20; // Gain energy from the dream
        } else if (dream == 1) {
            System.out.println("A ghostly ancient cat visits you in your dreams, whispering secrets of the Tuna Heist. (+10 energy, +10% success chance)");
            energy += 10; // Gain energy and success chance from the dream
            probabilitySuccessTuna += 10; // Boost success chance from the dream
        } else {
            System.out.println("You wake up from your seep. You feel well-rested. (+15 energy)");
            energy += 15; // Gain some energy from resting
        }
        home(new Scanner(System.in), new Random()); // Return to the home screen
    }

    /* 
     * This function handles the Golden Tuna heist. 
     * The player tries to steal it based on their success chance.
     */
    public static void stealGoldenTuna(Scanner in, Random random) {
        System.out.println("\nYou make your move, sneaking into the Dog Mafia’s hideout...");

        int roll = random.nextInt(100); // Roll a number between 0-99
        if (roll < probabilitySuccessTuna) {
            System.out.println("You slip past the guards like a shadow and snatch the Golden Tuna! YOU WIN!!!");
        } else {
            System.out.println("The heist goes wrong! The dogs spot you and chase you out. (-50 health, -50 energy)");
            health -= 50; // Lose health when caught
            energy -= 50; // Lose energy when caught
        }
        home(in, random); // Return to the home screen after the heist
    }
}
