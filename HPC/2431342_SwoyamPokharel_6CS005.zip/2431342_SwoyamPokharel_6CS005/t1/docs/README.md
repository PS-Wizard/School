# NOTE
The documentation for this coursework was done entirely in [typst](https://typst.app/). The source code for typst can be found at `./t1_docs.typ`. The `./layout.typ` defines the structure of the final pdf, and `images/` contains assets for cover page and some of the diagrams.

